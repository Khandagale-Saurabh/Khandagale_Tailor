function hand() {
    var c5 = document.getElementById('five');
    c5.src = "";
    c5.src = "5_1.png";
}

function Black_hand() {
    var c5 = document.getElementById('five');
    c5.src = "";
    c5.src = "Shirt4/Black_hand_full.png";
}


function blue_black_hand() {
    var c5 = document.getElementById('five');
    c5.src = "";
    c5.src = "Shirt/blue_black_sleeves.png";
}

function Pink_hand() {
    var c5 = document.getElementById('five');
    c5.src = "";
    c5.src = "Shit3/Pink_full.png";
}


function  light_blue_hand()
{
    var c5 = document.getElementById('five');
    c5.src = "";
    c5.src = "blue_light/long_ligth_blue.png"; 
}


function  hand_red_black()
{
    var c5 = document.getElementById('five');
    c5.src = "";
    c5.src = "red_black/long.png"; 
}


function hand_Dark_blue()
{
    var c1 = document.getElementById('five');
    c1.src = "";
    c1.src = "Dark_blue/long.png"
}

//==================================================collar===================================================

function collar() {
    var c1 = document.getElementById('one');
    c1.src = "";
    c1.src = "collar2.png"
}

function light_blue_collar() {
    var c1 = document.getElementById('one');
    c1.src = "";
    c1.src = "blue_light/collar_light_blue.png"
}

function blue_black_collar() {
    var c1 = document.getElementById('one');
    c1.src = "";
    c1.src = "blue_black_collar.png"
}


function black_collar() {
    var c1 = document.getElementById('one');
    c1.src = "";
    c1.src = "Shirt4/bsc-collar-prince-charile.png";
}


function collar_red_black()
{
    var c1 = document.getElementById('one');
    c1.src = "";
    c1.src = "red_black/collar.png"
}

function collar_Dark_blue()
{
    var c1 = document.getElementById('one');
    c1.src = "";
    c1.src = "Dark_blue/collar.png"
}

//========================================================= cuff========================================


let black_cuff = () => {
    var c1 = document.getElementById('four');
    c1.src = "";
    c1.src = "Shirt4/black_cuff.png"
}



function light_blue_cuff() {
    var c1 = document.getElementById('four');
    c1.src = "";
    c1.src = "blue_light/cuff.png"
}

function cuff_red_black()
{
    var c1 = document.getElementById('four');
    c1.src = "";
    c1.src = "red_black/cuff.png"  
}

function cuff_Dark_blue()
{
    var c1 = document.getElementById('four');
    c1.src = "";
    c1.src = "Dark_blue/cuff.png"    
}



//======================================================= BODY========================================================

function body_light_blue()
{
    var c2=document.getElementById('two');
    c2.src="";
    c2.src="blue_light/bottom.png"
}

function body_red_black()
{
    var c2=document.getElementById('two');
    c2.src="";
    c2.src="red_black/body.png"
}


function body_Dark_blue()
{
    //https://www.bombayshirts.com/products/navy-stretch-poplin?customisable=true


    var c2=document.getElementById('two');
    c2.src="";
    c2.src="Dark_blue/body.png"
}
